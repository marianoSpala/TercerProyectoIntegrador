const Categoria = require('../models/categoria');

// controlador para mostrar las categorias 
 const traeCategorias = async (req, res) => {
  try {
    const result = await Categoria.findAll();
    !result ? res.status(404).json({ error: 'No existen coincidencias' })
                : res.json(result);
  } catch (error) {
    console.error("Error al traer Categorias", error);
    res.status(500).json({ error: "Error al traer Categorias" });
  }
};

module.exports = {traeCategorias};