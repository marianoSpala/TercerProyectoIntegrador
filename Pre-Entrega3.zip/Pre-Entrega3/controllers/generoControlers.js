const ContieneGenero = require('../src/associations');

// controlador para crear la relacion de registro en ContieneGenero     
const crearGeneroProduccion = async (req, res) => {
    const {
      idProduccion,
      idGenero,
    } = req.body;
    try {
      const nuevaGeneroProduccion = await ContieneGenero.ContieneGenero.create({
      idProduccion,
      idGenero,
      });
      res.json(nuevaGeneroProduccion);
    } catch (error) {
      console.error("Error al crear relacion", error);
      res.status(500).json({ error: "Error al crear relacion" });
    }
};

// controlador para eliminar un registro en ContieneGenero por su ID 
 const eliminarContieneGenero = async (req, res) => {
  const id = parseInt(req.params.id);
  try {
    const result = await ContieneGenero.ContieneGenero.findByPk(id);
    if (!result) {
      res.status(404).json({ error: "Registro no encontrado" });
      return;
    }
    await result.destroy();
    res.json({ mensaje: "Registro eliminado con éxito" });
  } catch (error) {
    console.error("Error al eliminar Registro", error);
    res.status(500).json({ error: "Error al eliminar Registro" });
  }
};

module.exports = {crearGeneroProduccion, eliminarContieneGenero};