const Trailer = require('../src/associations');
const ObtenerTrailersView = require('../models/obtenerTrailersView');

// controlador para crear un registro en Trailer
const crearTrailer = async (req, res) => {
    const {
      direccionURL,
      idProduccion,
    } = req.body;
    try {
      const nuevoTrailer = await Trailer.Trailer.create({
        direccionURL,
        idProduccion,
      });
      res.json(nuevoTrailer);
    } catch (error) {
      console.error("Error al crear Trailer", error);
      res.status(500).json({ error: "Error al crear Trailer" });
    }
};

// controlador para listar todos los Trailers
const listarTrailers = async (req, res) => {
    try {
        const result = await ObtenerTrailersView.findAll();
        
        !result ? res.status(404).json({ error: 'No existen coincidencias' })
                : res.json(result);
                
        } catch (error) {
          
            console.error('Error al buscar Trailers:', error);
            res.status(500).json({ error: 'Error al buscar Trailers'});
        } 
};

// controlador para eliminar un Trailer por su ID 
 const eliminarTrailer = async (req, res) => {
  const id = parseInt(req.params.id);
  try {
    const result = await Trailer.Trailer.findByPk(id);
    if (!result) {
      res.status(404).json({ error: "Trailer no encontrada" });
      return;
    }
    await result.destroy();
    res.json({ mensaje: "Trailer eliminado con éxito" });
  } catch (error) {
    console.error("Error al eliminar Trailer", error);
    res.status(500).json({ error: "Error al eliminar Trailer" });
  }
};

module.exports = {crearTrailer, listarTrailers, eliminarTrailer};