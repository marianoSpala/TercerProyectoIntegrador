const Poster = require('../src/associations');
const ObtenerPostersView= require('../models/obtenerPostersView');

// controlador para crear un registro en Poster
const crearPoster = async (req, res) => {
    const {
        recurso,
      idProduccion,
    } = req.body;
    try {
      const nuevoPoster = await Poster.Poster.create({
        recurso,
        idProduccion,
      });
      res.json(nuevoPoster);
    } catch (error) {
      console.error("Error al crear Poster", error);
      res.status(500).json({ error: "Error al crear Poster" });
    }
};

// controlador para listar todos los Posters
const listarPosters = async (req, res) => {
    try {
        const result = await ObtenerPostersView.findAll();
        
        !result ? res.status(404).json({ error: 'No existen coincidencias' })
                : res.json(result);
                
        } catch (error) {
          
            console.error('Error al buscar Poster:', error);
            res.status(500).json({ error: 'Error al buscar Poster'});
        } 
};

// controlador para eliminar un Poster por su ID 
 const eliminarPoster = async (req, res) => {
  const id = parseInt(req.params.id);
  try {
    const result = await Poster.Poster.findByPk(id);
    if (!result) {
      res.status(404).json({ error: "Poster no encontrada" });
      return;
    }
    await result.destroy();
    res.json({ mensaje: "Poster eliminado con éxito" });
  } catch (error) {
    console.error("Error al eliminar Poster", error);
    res.status(500).json({ error: "Error al eliminar Poster" });
  }
};

module.exports = {crearPoster, listarPosters, eliminarPoster};