const PGW = require('../models/produccionGeneralView');
const {Sequelize} = require('sequelize');
const Genero = require('../src/associations');
const ContieneGenero = require('../src/associations');
const Produccion = require('../src/associations');

// controlador para listar todas la producciones
const listarProduccion = async (req, res) => {
    try {
        const result = await PGW.findAll();
        
        !result ? res.status(404).json({ error: 'No existen coincidencias' })
                : res.json(result);
                
        } catch (error) {
          
            console.error('Error al buscar la produccion:', error);
            res.status(500).json({ error: 'Error al buscar la produccion'});
        } 
};

// controlador para buscar una produccion por su id
const produccionID = async (req, res) => {
    try {
        const produccionId = parseInt(req.params.idProduccion.trim());
        const result = await PGW.findByPk(produccionId);
        
        !result ? res.status(404).json({ error: 'No existen coincidencias' })
                : res.json(result);
                
        } catch (error) {
          
            console.error('Error al buscar la produccion:', error);
            res.status(500).json({ error: 'Error al buscar la produccion'});
        } 
};

// controlador para buscar una produccion por su titulo o parte del mismo
const produccionTitulo = async (req, res) => {
    try {
        const nombre = req.params.titulo.trim();
        const result = await PGW.findAll({
            where: {
              titulo: {
                [Sequelize.Op.like]: `%${nombre}%`
              }
            }
          });
        
        !result ? res.status(404).json({ error: 'No existen coincidencias' })
                : res.json(result);
                
        } catch (error) {
          
            console.error('Error al buscar la produccion:', error);
            res.status(500).json({ error: 'Error al buscar la produccion'});
        } 
};

// controlador para buscar producciones por su categoria
const produccionCat = async (req, res) => {
    try {
        const nombre = req.params.nombre.trim();
        const result = await PGW.findAll({ where: {categoria: {
          [Sequelize.Op.like]: `%${nombre}%`
        }}});
        
        !result ? res.status(404).json({ error: 'No existen coincidencias' })
                : res.json(result);
                
        } catch (error) {
          
            console.error('Error al buscar la produccion:', error);
            res.status(500).json({ error: 'Error al buscar la produccion'});
        } 
};

// controlador para buscar producciones por genero
const produccionGenero = async (req, res) => {
    try {
    const nombre = req.params.nombre.trim();
    const result  = await Genero.Genero.findOne({ where: {nombre:{
      [Sequelize.Op.like]: `%${nombre}%`
    }}});
    const result2 = await ContieneGenero.ContieneGenero.findAll({where: {idGenero : (result.idGenero)}});
    const result3 = await PGW.findAll({where: {id: (result2.map(item => item.idProduccion))}});

    !result3 ? res.status(404).json({ error: 'No existen coincidencias' })
             : res.json(result3);

    } catch (error) {
        console.error('Error al buscar el genero:', error);
        res.status(500).json({ error: 'Error al buscar el genero'});

    } 
};

// controlador para buscar producciones por actor/actris
const produccionReparto = async (req, res) => { 
try {
    const nombre = req.params.nombre;
    const result = await PGW.findAll({
        where: {
          reparto: {
            [Sequelize.Op.like]: `%${nombre}%`
          }
        }
      });  
    result.length <= 0 ? res.status(404).json({ error: 'No existen coincidencias' })
                      : res.json(result);
            
    } catch (error) {
        console.error('Error al buscar el actor:', error);
        res.status(500).json({ error: 'Error al buscar el actor'});
  
    }

};

// controlador para crear una nueva Produccion      
const crearProduccion = async (req, res) => {
    const {
      titulo,
      categoria,
      temporadas,
      resumen,
    } = req.body;
    try {
      const nuevaProduccion = await Produccion.Produccion.create({
      titulo,
      categoria,
      temporadas,
      resumen,
      });
      res.json(nuevaProduccion);
    } catch (error) {
      console.error("Error al crear post", error);
      res.status(500).json({ error: "Error al crear post" });
    }
};

// controlador para modificar una Produccion por su id  
const actualizarProduccion = async (req, res) => {
    const id = parseInt(req.params.id);
    const {
        titulo,
        categoria,
        temporadas,
        resumen,
    } = req.body;
    try {
      const produccion = await Produccion.Produccion.findByPk(id);
      if (!produccion) {
        res.status(404).json({ error: "Produccion no encontrada" });
        return;
      }
  
      await produccion.update({
      titulo,
      categoria,
      temporadas,
      resumen,
      });
  
      res.json(post);
    } catch (error) {
      console.error("Error al actualizar Produccion", error);
      res.status(500).json({ error: "Error al actualizar Produccion" });
    }
};

// controlador para eliminar una Produccion por su id   
const eliminarProduccion = async (req, res) => {
    const id = parseInt(req.params.id);
    try {
      const produ = await Produccion.Produccion.findByPk(id);
      if (!produ) {
        res.status(404).json({ error: "Produccion no encontrada" });
        return;
      }
      await produ.destroy();
      res.json({ mensaje: "Produccion eliminada con éxito" });
    } catch (error) {
      console.error("Error al eliminar Produccion", error);
      res.status(500).json({ error: "Error al eliminar Produccion" });
    }
};
  
module.exports = {
listarProduccion,
produccionID,
produccionTitulo,
produccionCat,
produccionGenero,
produccionReparto,
crearProduccion,
actualizarProduccion,
eliminarProduccion  
};