const Actores = require('../src/associations');

// controlador para crear un registro en Actores
const crearActor = async (req, res) => {
    const {
     nombreCompleto,
    } = req.body;
    try {
      const nuevoActor = await Actores.Actores.create({
        nombreCompleto,
      });
      res.json(nuevoActor);
    } catch (error) {
      console.error("Error al crear Actor", error);
      res.status(500).json({ error: "Error al crear Actor" });
    }
};

// controlador para modificar un Actor por su id  
const modificarActor = async (req, res) => {
  const id  = parseInt(req.params.id);
  const {nombreCompleto} = req.body;
  try {
    const result = await Actores.Actores.findByPk(id);
    if (!result) {
      res.status(404).json({ error: "Actor no encontrado" });
      return;
    }
    await result.update({
      nombreCompleto
    });

    res.json(result);
  } catch (error) {
    console.error("Error al actualizar Actor", error);
    res.status(500).json({ error: "Error al actualizar Actor" });
  }
};

module.exports ={crearActor, modificarActor};