const Reparto = require('../src/associations');

// controlador para crear un registro en Reparto
const crearReparto = async (req, res) => {
    const {
      idProduccion,
      idActor,
    } = req.body;
    try {
      const nuevoReparto = await Reparto.Reparto.create({
        idProduccion,
        idActor,
      });
      res.json(nuevoReparto);
    } catch (error) {
      console.error("Error al crear registro", error);
      res.status(500).json({ error: "Error al crear registro" });
    }
};

// controlador para eliminar un registro en Reparto por su ID 
 const eliminarReparto = async (req, res) => {
  const id = parseInt(req.params.id);
  try {
    const result = await Reparto.Reparto.findByPk(id);
    if (!result) {
      res.status(404).json({ error: "Reparto no encontrada" });
      return;
    }
    await result.destroy();
    res.json({ mensaje: "PReparto eliminado con éxito" });
  } catch (error) {
    console.error("Error al eliminar Reparto", error);
    res.status(500).json({ error: "Error al eliminar Reparto" });
  }
};

module.exports = {crearReparto, eliminarReparto};