
const {DataTypes} = require('sequelize');
const {db} = require('../src/conexion');


//modelo de datos de tabla Actores
const Actores = db.define('Actores', {
    idActor:{
        type: DataTypes.INTEGER,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true,
    },
    nombreCompleto:
    {
      type: DataTypes.STRING(50),
    },
  },
    {
      tableName:'Actores',
      timestamps: false,
    }
    
)

module.exports = Actores;