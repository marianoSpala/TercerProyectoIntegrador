const {DataTypes} = require('sequelize');
const {db} = require('../src/conexion');

//modelo de datos de tabla Produccion
const Produccion = db.define('Produccion', {
    idProduccion:{
        type: DataTypes.INTEGER,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true,
    },
    titulo:
    {
      type: DataTypes.STRING(180),

    },
    categoria:
    {
      type: DataTypes.INTEGER,
      allowNull: false,
      
    },
    temporadas:
    {
      type: DataTypes.INTEGER,
      
    },
    resumen:
    {
      type: DataTypes.STRING(1400),
      
    },
    
  },
    {
      tableName:'Produccion',
      timestamps: false,
    }
    
)

module.exports = Produccion;