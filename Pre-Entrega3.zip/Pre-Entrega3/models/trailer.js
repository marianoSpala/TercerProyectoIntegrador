const {DataTypes} = require('sequelize');
const {db} = require('../src/conexion');

//modelo de datos de tabla Trailer
const Trailer = db.define('Trailer', {
    idTrailer:{
        type: DataTypes.INTEGER,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true,
    },
    direccionURL:
    {
      type: DataTypes.STRING(200),
    },
    idProduccion:{
        type: DataTypes.INTEGER,
       
    },
  },
  {
    tableName:'Trailer',
    timestamps: false,
  }
  
)
   
module.exports = Trailer;