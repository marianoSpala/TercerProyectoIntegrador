const {DataTypes} = require('sequelize');
const {db} = require('../src/conexion');

//modelo de datos de tabla Reparto
const ContieneGenero = db.define('ContieneGenero', {
    idContenedor:{
        type: DataTypes.INTEGER,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true,
    },
    idGenero:
    {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    idProduccion:
    {
      type: DataTypes.INTEGER,
      allowNull: false,
    },   
  },
    {
      tableName:'ContieneGenero',
      timestamps: false,
    }
    
)

module.exports = ContieneGenero;