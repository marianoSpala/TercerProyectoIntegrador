const {DataTypes} = require('sequelize');
const {db} = require('../src/conexion');


//modelo de datos de tabla Genero
const Genero = db.define('Genero', {
    idGenero:{
        type: DataTypes.INTEGER,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true,
    },
    nombre:
    {
      type: DataTypes.STRING(20),
    },
  },
  {
    tableName:'Genero',
    timestamps: false,
  }
  
)
  
module.exports = Genero;