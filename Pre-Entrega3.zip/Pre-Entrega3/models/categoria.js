const {DataTypes} = require('sequelize');
const {db} = require('../src/conexion');


//modelo de datos de tabla Categoria
const Categoria = db.define('Categoria', {
    idCategoria:{
        type: DataTypes.INTEGER,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true,
    },
    nombre:
    {
      type: DataTypes.STRING(20),
    },
  },
  {
    tableName:'Categoria',
    timestamps: false,
  }
  
)
 

module.exports = Categoria;