const {DataTypes} = require('sequelize');
const {db} = require('../src/conexion');

const ObtenerTrailersView = db.define('ObtenerTrailersView', {
    idTrailer:{
        type: DataTypes.INTEGER,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true,
    },
    URL:
    {
      type: DataTypes.STRING,
    },
    idProduccion:
    {
      type: DataTypes.INTEGER,    
    },
    tituloProduccion:
    {
      type: DataTypes.STRING,     
    },
     
  },
    {
      tableName:'ObtenerTrailersView',
      timestamps: false,
    }
    
)

module.exports = ObtenerTrailersView;
