const {DataTypes} = require('sequelize');
const {db} = require('../src/conexion');

const ObtenerPostersView = db.define('ObtenerPostersView', {
    idPoster:{
        type: DataTypes.INTEGER,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true,
    },
    recurso:
    {
      type: DataTypes.STRING,
    },
    idProduccion:
    {
      type: DataTypes.INTEGER,    
    },
    tituloProduccion:
    {
      type: DataTypes.STRING,     
    },
     
  },
    {
      tableName:'ObtenerPostersView',
      timestamps: false,
    }
    
)

module.exports = ObtenerPostersView;