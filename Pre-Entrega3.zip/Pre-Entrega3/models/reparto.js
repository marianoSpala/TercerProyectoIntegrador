const {DataTypes} = require('sequelize');
const {db} = require('../src/conexion');


//modelo de datos de tabla Reparto
const Reparto = db.define('Reparto', {
    id:{
        type: DataTypes.INTEGER,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true,
    },
    idProduccion:
    {
      type: DataTypes.INTEGER,
    
    },
    idActor:
    {
      type: DataTypes.INTEGER,
     
    },
  },
    {
      tableName:'Reparto',
      timestamps: false,
    }
    
)

module.exports = Reparto;