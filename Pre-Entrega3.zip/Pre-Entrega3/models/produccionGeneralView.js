const {DataTypes} = require('sequelize');
const {db} = require('../src/conexion');

const ProduccionGeneralView = db.define('ProduccionGeneralView', {
    id:{
        type: DataTypes.INTEGER,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true,
    },
    poster:
    {
      type: DataTypes.STRING,
    },
    titulo:
    {
      type: DataTypes.STRING,
    },
    categoria:
    {
      type: DataTypes.INTEGER,    
    },
    genero:
    {
      type: DataTypes.INTEGER,         
    },
    resumen:
    {
      type: DataTypes.STRING,     
    },
    temporadas:
    {
      type: DataTypes.INTEGER,      
    },
    reparto:
    {
      type: DataTypes.STRING,      
    },
    trailer:
    {
      type: DataTypes.STRING,     
    },   
  },
    {
      tableName:'ProduccionGeneralView',
      timestamps: false,
    }
    
)

module.exports = ProduccionGeneralView;
