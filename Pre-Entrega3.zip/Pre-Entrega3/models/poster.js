const {DataTypes} = require('sequelize');
const {db} = require('../src/conexion');


//modelo de datos de tabla Poster
const Poster = db.define('Poster', {
    idPoster:{
        type: DataTypes.INTEGER,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true,
    },
    recurso:
    {
      type: DataTypes.STRING(80),
    },
    idProduccion:{
        type: DataTypes.INTEGER,
       
    },
  },
  {
    tableName:'Poster',
    timestamps: false,
  }
  
)
 
module.exports = Poster;