//configuracion del entorno
const express = require('express');
const app = express();
const dotenv = require('dotenv');
dotenv.config();
const PORT = process.env.PORT || 3000;
const {authenticate, closeConnection} = require('./src/mysql');
const {db} = require('./src/conexion');

const router = express.Router();

//Middleware

app.use(express.json());

app.use(async (req, res, next) => {
    try {
      await authenticate();
      next();
    } catch (error) {
      res
        .status(500)
        .json({ error: "Error en el servidor", description: error.message });
    }
});


// CONTROLADORES

//importa Controladores para las rutas de Busqueda de Produccion
const ProduccionListaView = require('./controllers/produccionControllers');
const ProducionID = require('./controllers/produccionControllers');
const ProduccionTitulo = require('./controllers/produccionControllers');
const ProduccionCat = require('./controllers/produccionControllers');
const ProduccionGenero = require('./controllers/produccionControllers');
const ProduccionReparto = require('./controllers/produccionControllers');

// importa controlador para Crear/Actualizar/Eliminar  Produccion
const CrearProduccion = require('./controllers/produccionControllers');
const ActualizarProduccion = require('./controllers/produccionControllers');
const EliminarProduccion = require('./controllers/produccionControllers');

// importa controlador para Crear/Modificar un registro en Actores
const CrearActor = require('./controllers/actoresControllers');
const ModificarActor = require('./controllers/actoresControllers');

// importa controlador para Crear/Eliminar registro en ContieneGenero
const CrearGeneroProduccion = require('./controllers/generoControlers');
const EliminarContieneGenero = require('./controllers/generoControlers');

// importa controlador para Crear/Eliminar registro en Reparto
const CrearReparto = require('./controllers/repartoControllers');
const EliminarReparto = require('./controllers/repartoControllers');

// importa controlador para Crear/Listar/Eliminar Poster
const CrearPoster = require('./controllers/posterControllers');
const ObtenerPostersView = require('./controllers/posterControllers');
const DeletePoster = require('./controllers/posterControllers');

// importa controlador para Crear/Listar/Eliminar Trailer
const CrearTrailer = require('./controllers/trailerControllers');
const ObtenerTrailersView = require('./controllers/trailerControllers');
const DeleteTrailer = require('./controllers/trailerControllers');

const TraeCategorias = require('./controllers/categoriaControllers');
//------------------------------------------------------------------------------


//RUTAS (end points)
 
//ruta 
app.get('/', (req, res) => {
    res.status(200).send('Bienvenido a Trailerflix!');
});

// Lista todos los Posters con la Produccion a la que pertenecen
 app.get('/catalogo/posters', ObtenerPostersView.listarPosters); 
// Lista todos los Trailers con la Produccion a la que pertenecen
 app.get('/catalogo/trailers', ObtenerTrailersView.listarTrailers);
// Busca la producciones por titulo o parte del mismo.
 app.get('/catalogo/titulo/:titulo', ProduccionTitulo.produccionTitulo);
// Busca producciones por categoria (Pelicula o Serie)      
 app.get('/catalogo/categoria/:nombre', ProduccionCat.produccionCat);
// Busca producciones por genero (Por ejemplo: produccion/genero/Accion)
 app.get('/catalogo/genero/:nombre', ProduccionGenero.produccionGenero);
// Busca producciones por el nombre completo del actor/actriz o parte del mismo
 app.get('/catalogo/reparto/:nombre',ProduccionReparto.produccionReparto);
// Lista todo el catalogo con toda la informacion............................... (Igual al objeto json)
 app.get('/catalogo', ProduccionListaView.listarProduccion);
//Busca una produccion por su id.
 app.get('/catalogo/:idProduccion', ProducionID.produccionID);
// Lista las categorias
app.get('/categorias', TraeCategorias.traeCategorias);

// Ruta para Crear una nueva Produccion    
 app.post('/produccion', CrearProduccion.crearProduccion);
// Ruta para Crear un registro en Actores
 app.post('/produccion/actor', CrearActor.crearActor);
// Ruta para Crear un registro en ContieneGenero
 app.post('/produccion/genero', CrearGeneroProduccion.crearGeneroProduccion);
// Ruta para Crear un registro en Reparto
 app.post('/produccion/reparto', CrearReparto.crearReparto);
// Ruta para Crear un Poster
 app.post('/produccion/poster', CrearPoster.crearPoster);
// Ruta para Crear un Trailer
 app.post('/produccion/trailer', CrearTrailer.crearTrailer);

// Ruta para Modificar una Produccion    
 app.put('/produccion/:id', ActualizarProduccion.actualizarProduccion);
// Ruta para Modificar un registro en Actores
 app.put('/produccion/actores/:id', ModificarActor.modificarActor);

// Ruta para Eliminar una Produccion    
 app.delete('/produccion/:id', EliminarProduccion.eliminarProduccion);
// Ruta para Eliminar un Poster
 app.delete('/produccion/poster/:id', DeletePoster.eliminarPoster);
// Ruta para Eliminar un Trailer
 app.delete('/produccion/trailer/:id', DeleteTrailer.eliminarTrailer);
// Ruta para Eliminar un registro en Reparto
 app.delete('/produccion/reparto/:id', EliminarReparto.eliminarReparto);
// Ruta para Eliminar un registro en ContieneGenero
 app.delete('/produccion/genero/:id', EliminarContieneGenero.eliminarContieneGenero);

//Para rutas no existentes
app.get('*', (req, res) => {
      res.status(404).send('Ups! El sitio que buscas no existe.')
}); 

//configuracion del puerto local
app.listen(PORT, () => {
    console.log(`Servidor escuchando en el puerto ${PORT}`);
});

