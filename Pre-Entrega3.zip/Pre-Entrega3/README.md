# Documentación de la API Pre-Entrega 3
### Spala Mariano - Argentina Programa 4.0 - Backend, lu y mie 9 a 11 hs.

El objetivo de este documento es explicar las operaciones básicas que se pueden realizar sobre la base de datos MySQL "Trailerflix" con la API "Trailerflix".

## Índice de contenidos

- 1 [CRUD](#crud)
 - 1.1 [Create](#create)
 - 1.2 [Read](#read)
 - 1.3 [Update](#update)
 - 1.4 [Delete](#delete)
- 2 [Tabla URL](#tabla-url)
- 3 [Ejemplos de uso](#ejemplos-de-uso)
 - 3.1 [Ejemplo de uso del método POST](#ejemplo-de-uso-del-método-post)
 - 3.2 [Ejemplo de uso del método GET](#ejemplo-de-uso-del-método-get)
 - 3.3 [Ejemplo de uso del método PUT](#ejemplo-de-uso-del-método-put)
 - 3.4 [Ejemplo de uso del método DELETE](#ejemplo-de-uso-del-método-delete)
- 4 [Conexión a Trailerflix](#conexión-a-mongodb)
- 5 [Diagrama de Secuencia](#diagrama-de-secuencia)
- 6 [Diagrama de flujo](#diagrama-de-flujo)
- 7 [Listado de Errores](#listado-de-errores)
- 8 [Anexo DD.BB](#anexo-ddbb)


## Tabla URL

| URL                                    | Descripción                                                                                            | Método |
|----------------------------------------|--------------------------------------------------------------------------------------------------------|:------:|
|http://localhost:3008/categorias        |URL que nos retorna lascategorias                                                                       |  GET   |
|http://localhost:3008/catalogo        |URL general para visualizar el listado completo.                                                          |  GET   |
|http://localhost:3008/catalogo/:idProduccion |URL que nos retorna una produccion por su id.                                                      |  GET   |
|http://localhost:3008/catalogo/titulo/:titulo |URL que nos retorna producciones por titulo o parte del mismo.                                    |  GET   |
|http://localhost:3008/catalogo/categoria/:nombre |URL que nos retorna producciones por categoria.                                                |  GET   |
|http://localhost:3008/catalogo/genero/:nombre |URL que nos retorna producciones por genero.                                                      |  GET   |
|http://localhost:3008/catalogo/reparto/:nombre |URL que nos retorna producciones por el nombre completo del actor/actriz o parte del mismo.      |  GET   |
|http://localhost:3008/catalogo/trailers |URL que lista todos los Trailers con la Produccion a la que pertenecen.                                 |  GET   |
|http://localhost:3008/catalogo/posters  |URL que lista todos los Posters con la Produccion a la que pertenecen.                                  |  GET   |
|http://localhost:3008/*                   |URL para rutas inexistentes.                                                                          |  GET   |
|http://localhost:3008/produccion          |URL para Crear un registro en Produccion.                                                             |  POST  |
|http://localhost:3008/produccion/actor    |URL para Crear un registro en Actores.                                                                |  POST  |
|http://localhost:3008/produccion/genero   |URL para Crear un registro en ContieneGenero.                                                         |  POST  |
|http://localhost:3008/produccion/reparto  |URL para Crear un registro en Reparto.                                                                |  POST  |
|http://localhost:3008/produccion/poster   |URL para Crear un registro en Poster.                                                                 |  POST  |
|http://localhost:3008/produccion/trailer  |URL para Crear un registro en Trailer.                                                                |  POST  |
|http://localhost:3008/produccion/:id      |URL para Modificar un registro en Produccion  por su id.                                              |  PUT   |
|http://localhost:3008/produccion/actor/:id  |URL para Modificar un registro en Actores por su id.                                                |  PUT   |
|http://localhost:3008/produccion/:id        |URL para Eliminar un registro en Produccion por su id.                                              | DELETE |
|http://localhost:3008/produccion/poster/:id |URL para Eliminar un registro en Poster por su id.                                                  | DELETE |
|http://localhost:3008/produccion/trailer/:id  |URL para Eliminar un registro en Trailer por su id.                                               | DELETE |
|http://localhost:3008/produccion/reparto/:id  |URL para Eliminar un registro en Reparto por su id.                                               | DELETE |
|http://localhost:3008/produccion/genero/:id   |URL para Eliminar un registro en ContieneGenero por su id.                                        | DELETE |
|



## CRUD
El término CRUD es un acrónimo que se utiliza en el mundo de la programación para describir las operaciones básicas que se pueden realizar sobre una base de datos.

CRUD significa "Create, Read, Update, Delete"
(Crear, Leer, Actualizar y Borrar, respectivamente).

El término CRUD es conocido en español como ABM (Alta, Baja y Modificación) de datos en una base de datos.

Se explica a continuación como llevar a cabo estas operaciones dentro del contexto de la presente API:
Se denominará "produccion" a cada objeto que compone el catálogo.

### 'Create'
### El método POST
Este método nos permite crear un nuevo registro en la tabla Produccion. Es **MUY IMPORTANTE** crear los registros en todos los atributos de la produccion para que pueda ser agregara al listado de objetos en la base de datos. Ya que el listado completo se muestra como una VIEW y son necesarios todos los campos de la misma. Se ejemplifica el proceso en el **ejemplo de uso del método POST**.

Es necesario completar el ***Body*** de la petición con los datos de la produccion a crear.

#### El ***Body*** de la petición POST
Es aqui donde se vuelcan los datos del artículo nuevo.
El cuerpo de los datos bebe estar entre llaves,
el nombre de los atributos del artículo va entre comillas y para asignar el valor correspondiente a éstos se utilizan los dos puntos (:) luego del nombre.
Por ejemplo:

```js
  {
      "titulo": "The Matrix",
      "categoria": 1,
      "temporadas": null,
      "resumen": "Representa un futuro distópico en el que la humanidad está atrapada sin saberlo dentro de una realidad simulada llamada Matrix, que las máquinas inteligentes han creado para distraer a los humanos mientras usan sus cuerpos como fuente de energía en campos de cultivo. Cuando el programador informático Thomas Anderson, bajo el alias de hacker Neo, descubre la incómoda verdad, se une a una rebelión contra las máquinas junto con otras personas que han sido liberadas de la Matrix".
     
}
```
En este ejemplo, la propiedad "titulo" tiene un valor de "The Matrix",
la propiedad "categoria" vale 1,
la propiedad "temporadas" tiene un valor asignado de "null" ya que se trata de una Pelicula (si fuese una Serie, "temporadas" tendría un valor numérico con la cantidad total de temporadas) y
la propiedad "resumen" un valor de texto que describe la narrativa de la produccion.

Al ejecutar el método, se creará un nuevo registro en la tabla Produccion con los atributos declarados en el ***Body***.

### 'Read'
### El método GET
Mediante este método podemos realizar varias acciones de lectura:
-  Ver el listado completo de producciones.
-  Busca en el catálogo una o varias producciones por su **titulo** o parte del mismo.
-  Busca en el catálogo una o varias producciones por la **categoria** (Pelicula o Serie).
-  Busca en el catálogo una produccion específica por su **idProduccion**.
-  Busca en el catálogo una o varias a producciones por el nombre completo o parcial de algún miembro del **reparto**.
-  Busca en el catálogo una o varias a producciones por su **genero**.  
(Véase [Tabla URL](#tabla-url))


### 'Update'
### El método PUT
El método pus es utilizado en esta API para modificar los atributos de una produccion existente y los nombres de los actores.

Se debe pasar por parámetro el id de la/el produccion/actor a modificar. (Vease [Tabla URL](#tabla-url))

La modificación de la/el produccion/actor requiere que se cargue en el ***Body*** de la petición los nuevos atributos de interés.

#### El body de la petición PUT
En el ***Body***  del método, escribir el atributo con su nuevo valor.
En el siguiente ejemplo para el atributo "**nombreCompleto**", el nuevo valor es "Laurence Fishburne" cuyo **idActor** es 212:

``` js
   {
"nombreCompleto": "Laurence Fishburne"
}
```
Al ejecutar el método se modifica el nombreCompleto del Actor.

### 'Delete'
### El método DELETE
Este método nos permite eliminar un registro de una tabla.
Debe pasarse por parámetro el **id** del registro que se desea eliminar.
(Vease [Tabla URL](#tabla-url))

## Ejemplos de uso

 ### Ejemplo de uso del método **POST**
 Supongamos que queremos dar de alta una nueva produccion y que nos aparezca en el listado.
 Para ello, utilizamos el método **POST** para realizar el pedido a la URL.
 
 Primero se crea el registro en la tabla Produccion.
 La URL a utilizar será: http://localhost:3008/produccion  
 
  (Vease [Tabla URL](#tabla-url))

 En el ***Body*** de la petición declaramos las propiedades del objeto en el formato correspondiente:

 ```js
   {
      "titulo": "The Matrix",
      "categoria": 1,
      "temporadas": null,
      "resumen": "Representa un futuro distópico en el que la humanidad está atrapada sin saberlo dentro de una realidad simulada llamada Matrix, que las máquinas inteligentes han creado para distraer a los humanos mientras usan sus cuerpos como fuente de energía en campos de cultivo. Cuando el programador informático Thomas Anderson, bajo el alias de hacker Neo, descubre la incómoda verdad, se une a una rebelión contra las máquinas junto con otras personas que han sido liberadas de la Matrix".
     
   }
   ```
 Entonces podemos ejecutar la petición y crear un nuevo registro en la tabla **Produccion** que quedará asentado en la base de datos. Es importante tener en cuenta el **id** de la nueva producción ya que lo utulizaremos en los pasos posteriores.

 Segundo, debemos dar de alta los Actores si es que no existen en la base de datos.
 La URL a utilizar será: http://localhost:3008/produccion/actor 

   (Vease [Tabla URL](#tabla-url))

 En el ***Body*** de la petición declaramos las propiedades del objeto en el formato correspondiente:

 ```js
   {
       "nombreCompleto": "Keanu Reeves"
     
 }
  ```
 Ejecutamos la petición y se creará el registro en la tabla **Actores**. Es importante tener en cuenta el **id** del nuevo actor generados automáticamente por el sistema, ya que lo usaremos para establecer la relación entre la producción y el actor en el siguiente paso:

 Tercero, creamos el registro en la tabla **Reparto** para establece la relación entre **Produccion** y **Actores**:
 La URL a utilizar será: http://localhost:3008/produccion/reparto

   (Vease [Tabla URL](#tabla-url))

 En el ***Body*** de la petición declaramos las propiedades del objeto en el formato correspondiente:

 ```js
   {
    "idProduccion":36,
    "idActor":211
     
 }
  ```
 Ejecutamos la petición y se creará el registro en la tabla **Reparto**.

 Cuarto, hay que generar una relación entre la nueva produccion y los géneros que incluye. Para ello nos valemos de la tabla **ContieneGenero**.
 La URL a utilizar será: http://localhost:3008/produccion/genero 

 (Vease [Tabla URL](#tabla-url))

 En el ***Body*** de la petición declaramos las propiedades del objeto en el formato correspondiente:

 ```js
   {
    
    "idGenero":1,
    "idProduccion":36
 }
  ```

 Ejecutamos la petición y se crea el registro en la tabla **ContieneGenero**.

 Para finalizar la operación, tenemos que crear un registro en **Poster** y un registro en **Trailer**, ambos vinculados a la nueva producción a través del **idProduccion**:

 Para crear un registro en **Poster** 
 La URL a utilizar será: http://localhost:3008/produccion/poster 

 (Vease [Tabla URL](#tabla-url))

 En el ***Body*** de la petición declaramos las propiedades del objeto en el formato correspondiente:

 ```js
   {
    
    "recurso":"/posters/36.jpg",
    "idProduccion":36
 }
  ```
 Ejecutamos la petición y se creará el registro en la tabla **Poster**.

 Por último hacemos lo mismo con la tabla **Trailer**:
 Para crear un registro en **Trailer** 
 La URL a utilizar será: http://localhost:3008/produccion/trailer 

 (Vease [Tabla URL](#tabla-url))

 En el ***Body*** de la petición declaramos las propiedades del objeto en el formato correspondiente:

 ```js
   {
    
    "direccionURL":"https://www.youtube.com/watch?v=vKQi3bBA1y8",
    "idProduccion":36
 }
  ```
 Ejecutamos la petición y se creará el registro en la tabla **Trailer**.

 Si la produccion NO cuenta con un Poster o un Trailer podemos colocar las comillas solas en el valor de **recurso** o **direcionURL**.

 Bien, hemos creado una nueva Producción con todos sus atributos y todas sus relaciones.


 ### Ejemplos de uso del método **GET**
 Si queremos acceder al listado del catálogo completo registrado en la base de datos, utilizaremos el método **GET**.
 
 La URL correspondiente a dicha consulta será: http://localhost:3008/catalogo  
 (Vease [Tabla URL](#tabla-url))
 
 Este método NO lleva contenido en el ***Body***, y ejecuta una VIEW almacenada en la base de datos.
  
 Al ejecutarlo, se desplegará el listado de las producciones en formato JSON, como un Array de objetos.

 ```js
 [
  {
    "id": 1,
    "poster": "/posters/1.jpg",
    "titulo": "The Crown",
    "categoria": "Serie",
    "genero": "Drama,Hechos verídicos",
    "resumen": "Este drama narra las rivalidades políticas y el romance de la reina Isabel II, así como los sucesos que moldearon la segunda mitad del siglo XX.",
    "temporadas": 4,
    "reparto": "Claire Fox,Helena Bonham Carter,Matt Smith,Olivia Colman,Tobias Menzies,Vanessa Kirby",
    "trailer": ""
  },
  {
    "id": 2,
    "poster": "/posters/2.jpg",
    "titulo": "Riverdale",
    "categoria": "Serie",
    "genero": "Drama,Ficción,Misterio",
    "resumen": "El paso a la edad adulta incluye sexo, romance, escuela y familia. Para Archie y sus amigos, también hay misterios oscuros.",
    "temporadas": 5,
    "reparto": "Camila Mendes,Casey Cott,Lili Reinhart,Mädchen Amick,Madelaine Petsch,Marisol Nichols",
    "trailer": ""
  },
  {
    "id": 3,
    "poster": "/posters/3.jpg",
    "titulo": "The Mandalorian",
    ...(etc)
  },
  ...(etc)
 ]
 ```
 Otro ejemplo de este método es el buscar producciones por un **titulo**. Podemos enviar por parámetro el título completo o parte del mismo.

 Valiéndonos de la petición **GET**, en este ejemplo, queremos las producciones que en su **titulo** contenga "leyenda", entonces enviamos la siguiente URL: http://localhost:3008/catalogo/titulo/leyenda

 Luego ejecutamos la petición.

 La respuesta del sistema:

 ``` js
 [
  {
    "id": 33,
    "poster": "/posters/33.jpg",
    "titulo": "Soy leyenda",
    "categoria": "Película",
    "genero": "Drama,Ficción,Terror",
    "resumen": "Años después de que una plaga mate a la mayoría de la humanidad y transforme al resto en monstruos, el único superviviente en la ciudad de Nueva York lucha valientemente para encontrar una cura.",
    "temporadas": null,
    "reparto": "Alice Braga,Charlie Tahan,Dash Mihok,Emma Thompson,Salli Richardson-Whitfield,Will Smith,Willow Smith",
    "trailer": "https://www.youtube.com/embed/dtKMEAXyPkg"
  }
]

 ```
 Si ejecutamos la peticion **GET** con la siguiente URL: http://localhost:3008/categorias 
 (Vease [Tabla URL](#tabla-url))
 Nos devuelve las categorias con sus respectivos id:
 
 ``` js
 [
  {
    "idCategoria": 1,
    "nombre": "Película"
  },
  {
    "idCategoria": 2,
    "nombre": "Serie"
  }
 ]

 ```
 Otro ejemplo de petición **GET** es el de filtrar el catálogo por **reparto**, es decir, buscamos el nombre completo o parcial de algún actor o actriz;
 Por ejemplo: http://localhost:3008/catalogo/reparto/matt
 Nos retorna:

 ``` js
 [
  {
    "id": 1,
    "poster": "/posters/1.jpg",
    "titulo": "The Crown",
    "categoria": "Serie",
    "genero": "Drama,Hechos verídicos",
    "resumen": "Este drama narra las rivalidades políticas y el romance de la reina Isabel II, así como los sucesos que moldearon la segunda mitad del siglo XX.",
    "temporadas": 4,
    "reparto": "Claire Fox,Helena Bonham Carter,Matt Smith,Olivia Colman,Tobias Menzies,Vanessa Kirby",
    "trailer": ""
  },
  {
    "id": 12,
    "poster": "/posters/12.jpg",
    "titulo": "Friends",
    "categoria": "Serie",
    "genero": "Comedia,Drama,Familia",
    "resumen": "'Friends' narra las aventuras y desventuras de seis jóvenes de Nueva York: Rachel, Monica, Phoebe, Ross, Chandler y Joey. Ellos forman una unida pandilla de amigos que viven en Manhattan y que suelen reunirse en sus apartamentos o en su bar habitual cafetería, el Central Perk. A pesar de los numerosos cambios que se producen en sus vidas, su amistad es inquebrantable en la dura batalla por salir adelante en sus periplos profesionales y personales.",
    "temporadas": 10,
    "reparto": "Courteney Cox,David Schwimmer,Jennifer Aniston,Lisa Kudrow,Matt LeBlanc,Matthew Perry",
    "trailer": ""
  },
  {
    "id": 25,
    "poster": "/posters/25.jpg",
    "titulo": "Contra lo imposible (Ford versus Ferrari)",
    "categoria": "Película",
    "genero": "Aventura,Drama,História",
    "resumen": "Los ganadores del Premio de la Academia® Matt Damon y Christian Bale protagonizan CONTRA LO IMPOSIBLE, basada en la historia real del visionario diseñador americano de automóviles Carroll Shelby (Damon) y el intrépido piloto británico Ken Miles (Bale). Juntos construyen un nuevo coche de carreras para Ford Motor Company y así enfrentar a Enzo Ferrari en las 24 Horas de Le Mans en Francia en 1966.",
    "temporadas": null,
    "reparto": "Caitriona Balfe,Christian Bale,Jon Bernthal,Josh Lucas,Matt Damon,Noah Jupe",
    "trailer": "https://www.youtube.com/embed/SOVb0-2g1Q0"
  },
  {
    "id": 28,
    "poster": "/posters/28.jpg",
    "titulo": "Contagio",
    "categoria": "Película",
    "genero": "Drama,Ficción,Suspenso",
    "resumen": "De repente, sin saber cuál es su origen, aunque todo hace sospechar que comienza con el viaje de una norteamericana a un casino de Hong Kong, un virus mortal comienza a propagarse por todo el mundo. En pocos días, la enfermedad empieza a diezmar a la población. El contagio se produce por mero contacto entre los seres humanos. Un thriller realista y sin efectos especiales sobre los efectos de una epidemia.",
    "temporadas": null,
    "reparto": "Gwyneth Paltrow,Jennifer Ehle,Jude Law,Kate Winslet,Laurence Fishburne,Marion Cotillard,Matt Damon",
    "trailer": "https://www.youtube.com/embed/4sYSyuuLk5g"
  },
  {
    "id": 30,
    "poster": "/posters/30.jpg",
    "titulo": "The Martian",
    "categoria": "Película",
    "genero": "Aventura,Drama,Sci-Fi",
    "resumen": "Durante una misión a Marte de la nave tripulada Ares III, una fuerte tormenta se desata dando por desaparecido y muerto al astronauta Mark Watney (Matt Damon), sus compañeros toman la decisión de irse pero él ha sobrevivido. Está solo y sin apenas recursos en el planeta. Con muy pocos medios deberá recurrir a sus conocimientos, su sentido del humor y un gran instinto de supervivencia para lograr sobrevivir y comunicar a la Tierra que todavía está vivo esperando que acudan en su rescate.",
    "temporadas": null,
    "reparto": "Jeff Daniels,Jessica Chastain,Kate Mara,Kristen Wiig,Matt Damon,Michael Peña,Sean Bean",
    "trailer": "https://www.youtube.com/embed/XvB58bCVfng"
  }
 ]

 ```

 ### Ejemplo de uso del método **PUT**
 Supongamos que queremos modificar el contenido de un registro en la tabla **Actores**. Lo único que podemos modificar aquí es el nombre del actor que se refleja en el atributo **nombreCompleto** de la tabla **Actores**, y valiéndonos del **idActor** podemos localizar al actor en la tabla y modificar su nombre.
 Haremos uso del método **PUT** para llevar a cabo dicha tarea.

 La URL correspondiente será: http://localhost:3008/produccion/actor/200         
 (Vease [Tabla URL](#tabla-url))
 
 En el ***Body** de la petición escribiremos el precio nuevo entre corchetes:
 ``` js
 {
    
    "nombreCompleto":"Carlos Villagran",
    
 }

 ```
 Al ejecutar la petición se modificará el nombre del actor cuyo **id** (200) pasamos por parámetro.

 ### Ejemplo de uso del método **DELETE**
 Para eliminar un registro específico existente en la base de datos recurriremos al método **DELETE** y utilizaremos el campo unívoco del **idProduccion** en el parámetro que enviemos por la ruta.
 Vale la aclaración que para eliminar una produccion primero debemos eliminar sus relaciones con otras tablas y con otras entidades.
 Supongamos que el **idProduccion** que deseamos eliminar es 12.
 Primero debemos eliminar el registro en **Reparto**, **ContieneGénero**, **Trailer** y **Poster** que son las tablas con las que se relaciona directamente la **Produccion**. Solo entonces podremos eliminar la producción por completo.
 La URL correspondiente será: http://localhost:3008/produccion/12
 
 Este método no lleva contenido en el ***Body***.
 
 Al ejecutar la petición, se eliminará permanentemente el registro cuyo **idProduccion** es 12.


## Conexión a MySQL
La conexión con la base de datos de se declara en el archivo .env, cuyo contenido se muestra a continuación:

``` js
PORT=3008
DATABASE=Trailerflix
DBUSER=root
PASSWORD=*****
HOST=localhost

```
**PORT**, define el puerto local (3008 en este caso) por donde se enviarán las rutas y las peticiones CRUD, así como también se recibirán las respuestas de las peticiones. Este puerto hace las veces de servidor web.
**DATABASE** define el nombre de la base de datos.
**DBUSER** define al usuario.
**PASSWORD** define la contraseña del usuario para acceder a la base de datos.
**HOST** define el huésped local.

## Diagrama de secuencia
``` mermaid
sequenceDiagram
    participant User
    participant Api
     participant DDBB
    User->>+Api: Carga de Datos y peticiones
    Api-->>+DDBB: CRUD y Acceso a datos
    DDBB-->>+Api: Respuesta (datos)
    Api->>+User: Mostrar datos
```


## Diagrama de flujo
``` mermaid
graph TD;
    HTTP-->REQUEST;
    REQUEST-->localhost;
    localhost-->MySQL;
    MySQL-->JSON;
    JSON--->localhost;
    localhost-->RESPONSE;
    RESPONSE-->HTTP;
```


## Listado de Errores
- Error: "**Error en el formato del elemento a ...**" ; error en el formato de los datos del artículo afectado.
- Error: "**Error de conexion a DB**"  ; error al establecer la conexion con la base de datos MongoDB.
- Error: "**Error al acceder a ...**" ; error del sistema al acceder a la colección "computacion" en la base de datos.
- Error: "**No existen coincidencias**" ; el sistema no encuentra coincidencia entre el valor pasado por parámetro y el registro de una produccion en la base de datos.



## Anexo DD.BB

use Trailerflix;

create table Categoria(
idCategoria int not null auto_increment,
nombre varchar (20),
primary key (idCategoria)
);

create table Genero(
idGenero int not null auto_increment,
nombre varchar (20),
primary key (idGenero)
);

create table Actores(
idActor int not null auto_increment,
nombreCompleto varchar (50),
primary key (idActor)
);

create table Trailer(
idTrailer int not null auto_increment,
direccionURL varchar (200),
idProduccion int,
primary key (idTrailer),
foreign key (idProduccion) references Produccion (idProduccion)
);

create table Poster(
idPoster int not null auto_increment,
recurso varchar (80),
idProduccion int,
primary key (idPoster),
foreign key (idProduccion) references Produccion (idProduccion)
);
create table ContieneGenero (
idContenedor int not null auto_increment,
idGenero int,
idProduccion int,
primary key (idContenedor),
foreign key (idProduccion) references Produccion (idProduccion),
foreign key (idGenero) references Genero (idGenero)
);

create table Produccion(
idProduccion int not null auto_increment,
titulo varchar (180),
categoria int,
temporadas int,
resumen varchar (1400),
primary key (idProduccion),
foreign key (categoria) references Categoria (idCategoria)
);

create table Reparto(
id int not null auto_increment,
idProduccion int,
idActor int,
primary key (id),
foreign key (idProduccion) references Produccion (idProduccion),
foreign key (idActor) references Actores (idActor)
);

insert into Categoria (idCategoria, nombre)
values ( 1, 'Película'), ( 2, 'Serie');

insert into Genero (idGenero, nombre)
values ( 1, 'Ciencia Ficción'), 
       ( 2, 'Suspenso'),
       ( 3, 'Drama'),
       ( 4, 'Crimen'),
       ( 5, 'Fantasía'),
       ( 6, 'Comedia'),
       ( 7, 'História'),
       ( 8, 'Drama Histórico'),
       (9, 'Familia'),
      (10, 'Sucesos'),
	  (11, 'Ficción'),
	  (12, 'Misterio'),
      (13, 'Hechos verídicos'),
      (14, 'Sci-Fi'),
      (15, 'Western'),
      (16, 'Tecnología'),
      (17, 'Acción'),
      (18, 'Aventura'),
      (19, 'Terror'),
      (20, 'Intriga');

INSERT INTO Poster (recurso, idProduccion)
VALUES 
  ('/posters/1.jpg', 1),
  ('/posters/2.jpg', 2),
  ('/posters/3.jpg', 3),
  ('/posters/4.jpg', 4),
  ('/posters/5.jpg', 5),
  ('/posters/6.jpg', 6),
  ('/posters/7.jpg', 7),
  ('/posters/8.jpg', 8),
  ('/posters/9.jpg', 9),
  ('/posters/10.jpg', 10),
  ('/posters/11.jpg', 11),
  ('/posters/12.jpg', 12),
  ('/posters/13.jpg', 13),
  ('/posters/14.jpg', 14),
  ('/posters/15.jpg', 15),
  ('/posters/16.jpg', 16),
  ('/posters/17.jpg', 17),
  ('/posters/18.jpg', 18),
  ('/posters/19.jpg', 19),
  ('/posters/20.jpg', 20),
  ('/posters/21.jpg', 21),
  ('/posters/22.jpg', 22),
  ('/posters/23.jpg', 23),
  ('/posters/24.jpg', 24),
  ('/posters/25.jpg', 25),
  ('/posters/26.jpg', 26),
  ('/posters/27.jpg', 27),
  ('/posters/28.jpg', 28),
  ('/posters/29.jpg', 29),
  ('/posters/30.jpg', 30),
  ('/posters/31.jpg', 31),
  ('/posters/32.jpg', 32),
  ('/posters/33.jpg', 33),
  ('/posters/34.jpg', 34),
  ('/posters/35.jpg', 35);
  
  
  insert into Trailer (direccionURL, idProduccion)
  values("", 1),
        ("", 2),
("https://www.youtube.com/embed/aOC8E8z_ifw", 3),
("", 4),
("", 5),
("", 6),
("https://www.youtube.com/embed/zAGVQLHvwOY", 7),
("", 8),
("", 9),
("", 10),
("https://www.youtube.com/embed/WBb3fojgW0Q", 11),
("", 12),
("", 13),
("https://www.youtube.com/embed/KKziOmsJxzE", 14),
("https://www.youtube.com/embed/s9APLXM9Ei8", 15),
("https://www.youtube.com/embed/qLFBcdd6Qw0", 16),
("https://www.youtube.com/embed/pWrioRji60A", 17),
("", 18),
("", 19),
("https://www.youtube.com/embed/VHSoCnDioAo", 20),
("https://www.youtube.com/embed/rBxcF-r9Ibs", 21),
("https://www.youtube.com/embed/AGQ7OkmIx4Q", 22),
("https://www.youtube.com/embed/hZeFeYSmBcg", 23),
("https://www.youtube.com/embed/BE6inv8Xh4A", 24),
("https://www.youtube.com/embed/SOVb0-2g1Q0", 25),
("", 26),
("https://www.youtube.com/embed/nat3u3gAVLE", 27),
("https://www.youtube.com/embed/4sYSyuuLk5g", 28),
("https://www.youtube.com/embed/BIn8iANwEog", 29),
("https://www.youtube.com/embed/XvB58bCVfng", 30),
("https://www.youtube.com/embed/XRYL5spvEcI", 31),
("", 32),
("https://www.youtube.com/embed/dtKMEAXyPkg", 33),
("", 34),
("", 35);

insert into Actores(idActor, nombreCompleto)
values (1, 'Claire Fox'),
(2, 'Olivia Colman'),
(3, 'Matt Smith'),
(4, 'Tobias Menzies'),
(5, 'Vanessa Kirby'),
(6, 'Helena Bonham Carter'),
(7, 'Lili Reinhart'),
(8, 'Casey Cott'),
(9, 'Camila Mendes'),
(10, 'Marisol Nichols'),
(11, 'Madelaine Petsch'),
(12, 'Mädchen Amick'),
(13, 'Pedro Pascal'),
(14, 'Carl Weathers'),
(15, 'Misty Rosas'),
(16, 'Chris Bartlett'),
(17, 'Rio Hackford'),
(18, 'Giancarlo Esposito'),
(19, 'Tom Hopper'),
(20, 'David Castañeda'),
(21, 'Emmy Raver-Lampman'),
(22, 'Robert Sheehan'),
(23, 'Aidan Gallagher'),
(24, 'Elliot Page'),
(25, 'Anya Taylor-Joy'),
(26, 'Thomas Brodie-Sangster'),
(27, 'Harry Melling'),
(28, 'Moses Ingram'),
(29, 'Chloe Pirrie'),
(30, 'Janina Elkin'),
(31, 'Millie Bobby Brown'),
(32, 'Henry Cavill'),
(33, 'Sam Claflin'),
(34, 'Louis Partridge'),
(35, 'Adeel Akhtar'),
(36, 'Joaquin Phoenix'),
(37, 'Robert De Niro'),
(38, 'Zazie Beetz'),
(39, 'Frances Conroy'),
(40, 'Brett Cullen'),
(41, 'Shea Whigham'),
(42, 'Robert Downey Jr.'),
(43, 'Chris Evans'),
(44, 'Mark Ruffalo'),
(45, 'Chris Hemsworth'),
(46, 'Scarlett Johansson'),
(47, 'Jeremy Renner'),
(48, 'Emilia Clarke'),
(49, 'Lena Headey'),
(50, 'Sophie Turner'),
(51, 'Kit Harington'),
(52, 'Peter Dinklage'),
(53, 'Nikolaj Coster-Waldau'),
(54, 'Grant Gustin'),
(55, 'Carlos Valdes'),
(56, 'Danielle Panabaker'),
(57, 'Candice Patton'),
(58, 'Jesse L. Martin'),
(59, 'Tom Cavanagh'),
(60, 'Jim Parsons'),
(61, 'Johnny Galecki'),
(62, 'Kaley Cuoco'),
(63, 'Simon Helberg'),
(64, 'Kunal Nayyar'),
(65, 'Melissa Rauch'),
(66, 'Mayim Bialik'),
(67, 'Jennifer Aniston'),
(68, 'Courteney Cox'),
(69, 'Lisa Kudrow'),
(70, 'David Schwimmer'),
(71, 'Matthew Perry'),
(72, 'Matt LeBlanc'),
(73, 'Amybeth McNulty'),
(74, 'Geraldine James'),
(75, 'R. H. Thomson'),
(76, 'Corrine Koslo'),
(77, 'Dalila Bela'),
(78, 'Lucas Jade Zumann'),
(79, 'Gillian Anderson'),
(80, 'David Duchovny'),
(81, 'Mitch Pileggi'),
(82, 'Robert Patrick'),
(83, 'Tom Braidwood'),
(84, 'Bruce Harwood'),
(85, 'Jared Harris'),
(86, 'Stellan Skarsgård'),
(87, 'Emily Watson'),
(88, 'Paul Ritter'),
(89, 'Jessie Buckley'),
(90, 'Adam Nagaitis'),
(91, 'Evan Rachel-Wood'),
(92, 'Thandie Newton'),
(93, 'Jeffrey Wright'),
(94, 'Tessa Thompson'),
(95, 'Ed Harris'),
(96, 'Luke Hemsworth'),
(97, 'Lee Pace'),
(98, 'Scoot McNairy'),
(99, 'Mackenzie Davis'),
(100, 'Kerry Bishé'),
(101, 'Toby Huss'),
(102, 'Alana Cavanaugh'),
(103, 'Jessica Chastain'),
(104, 'John Malkovich'),
(105, 'Colin Farrell'),
(106, 'Common'),
(107, 'Geena Davis'),
(108, 'Ioan Gruffudd'),
(109, 'Margot Robbie'),
(110, 'Ewan McGregor'),
(111, 'Mary Elizabeth Winstead'),
(112, 'Jurnee Smollett'),
(113, 'Rosie Perez'),
(114, 'Chris Messina'),
(115, 'Stacy Martin'),
(116, 'Rhona Mitra'),
(117, 'Theo James'),
(118, 'Peter Ferdinando'),
(119, 'Lia Williams'),
(120, 'Toby Jones'),
(121, 'Dwayne Johnson'),
(122, 'Kevin Hart'),
(123, 'Jack Black'),
(124, 'Karen Gillan'),
(125, 'Awkwafina'),
(126, 'Nick Jonas'),
(127, 'Miranda Cosgrove'),
(128, 'Kate Walsh'),
(129, 'Omar Epps'),
(130, 'Angus Macfadyen'),
(131, 'Jorja Fox'),
(132, 'Enver Gjokaj'),
(133, 'Bill Skarsgård'),
(134, 'Bill Hader'),
(135, 'James McAvoy'),
(136, 'Isaiah Mustafa'),
(137, 'Jay Ryan'),
(138, 'Chadwick Boseman'),
(139, 'Michael B. Jordan'),
(140, 'Lupita Nyongo'),
(141, 'Danai Gurira'),
(142, 'Martin Freeman'),
(143, 'Daniel Kaluuya'),
(144, 'Christian Bale'),
(145, 'Matt Damon'),
(146, 'Caitriona Balfe'),
(147, 'Josh Lucas'),
(148, 'Noah Jupe'),
(149, 'Jon Bernthal'),
(150, 'Génesis Rodríguez'),
(151, 'Vincent Piazza'),
(152, 'Benjamin Sokolow'),
(153, 'Emily Bayiokos'),
(154, 'Amy Manson'),
(155, 'Luke Allen-Gale'),
(156, 'Nina Bergman'),
(157, 'Dominic Mafham'),
(158, 'James Weber Brown'),
(159, 'Lorina Kamburova'),
(160, 'Marion Cotillard'),
(161, 'Laurence Fishburne'),
(162, 'Jude Law'),
(163, 'Kate Winslet'),
(164, 'Jennifer Ehle'),
(165, 'Gwyneth Paltrow'),
(166, 'Florence Pugh'),
(167, 'David Harbour'),
(168, 'O.T. Fagbenle'),
(169, 'Rachel Weisz'),
(170, 'William Hurt'),
(171, 'Ray Winstone'),
(172, 'Emma Stone'),
(173, 'Kristen Wiig'),
(174, 'Jeff Daniels'),
(175, 'Michael Peña'),
(176, 'Sean Bean'),
(177, 'Kate Mara'),
(178, 'Alicia Vikander'),
(179, 'Domhnall Gleeson'),
(180, 'Oscar Isaac'),
(181, 'Sonoya Mizuno'),
(182, 'Corey Johnson'),
(183, 'Claire Selby'),
(184, 'Gana Bayarsaikhan'),
(185, 'Bryce Dallas Howard'),
(186, 'Chris Pratt'),
(187, 'Irrfan Khan'),
(188, 'Vincent DOnofrio'),
(189, 'Omar Sy'),
(190, 'Nick Robinson'),
(191, 'Judy Greer'),
(192, 'Will Smith'),
(193, 'Alice Braga'),
(194, 'Charlie Tahan'),
(195, 'Dash Mihok'),
(196, 'Salli Richardson-Whitfield'),
(197, 'Willow Smith'),
(198, 'Emma Thompson'),
(199, 'Ryan Gosling'),
(200, 'Claire Foy'),
(201, 'Jason Clarke'),
(202, 'Kyle Chandler'),
(203, 'Corey Stoll'),
(204, 'Patrick Fugit'),
(205, 'John Boyega'),
(206, 'Scott Eastwood'),
(207, 'Cailee Spaeny'),
(208, 'Jing Tian'),
(209, 'Rinko Kikuchi'),
(210, 'Burn Gorman');

INSERT INTO Produccion (idProduccion, titulo, categoria, temporadas, resumen)
VALUES

(1, "The Crown", 2, 4, "Este drama narra las rivalidades políticas y el romance de la reina Isabel II, así como los sucesos que moldearon la segunda mitad del siglo XX."),    
(2, "Riverdale", 2, 5, "El paso a la edad adulta incluye sexo, romance, escuela y familia. Para Archie y sus amigos, también hay misterios oscuros."),
(3, "The Mandalorian", 2, 2, "Ambientada tras la caída del Imperio y antes de la aparición de la Primera Orden, la serie sigue los pasos de un pistolero solitario en las aventuras que protagoniza en los confines de la galaxia, donde no alcanza la autoridad de la Nueva República."),
(4, "The Umbrella Academy", 2, 1,  "La muerte de su padre reúne a unos hermanos distanciados y con extraordinarios poderes que descubren impactantes secretos y una amenaza que se cierne sobre la humanidad."),
(5, "Gambito de Dama", 2, 1, "En los cincuenta, una joven de un orfanato descubre que tiene un increíble don para el ajedrez y recorre el arduo camino a la fama mientras lucha contra las adicciones."),
(6, "Enola Holmes", 1, null, "La hermana menor de Sherlock, descubre que su madre ha desaparecido y se dispone a encontrarla. En su búsqueda, saca a relucir el sabueso que corre por sus venas y se encuentra con una conspiración que gira en torno a un misterioso lord, demostrando que su ilustre hermano no es el único talento en la familia."),
(7, "Guasón", 1, null, "Arthur Fleck (Phoenix) es un hombre ignorado por la sociedad, cuya motivación en la vida es hacer reír. Pero una serie de trágicos acontecimientos le llevarán a ver el mundo de otra forma. Película basada en el popular personaje de DC Comics Joker, conocido como archivillano de Batman, pero que en este film tomará un cariz más realista y oscuro."),
(8, "Avengers: End Game", 1, null, "Después de los devastadores eventos de los Vengadores: Infinity War (2018), el universo está en ruinas. Con la ayuda de los aliados restantes, los Vengadores se reúnen una vez más para revertir las acciones de Thanos y restaurar el equilibrio del universo."),     
(9, "Juego de tronos", 2, 8, "En un mundo fantástico y en un contexto medieval varias familias, relativas a la nobleza, se disputan el poder para dominar el territorio ficticio de Poniente (Westeros) y tomar el control de los Siete Reinos desde el Trono de Hierro, lugar donde el rey ejerce el poder."),
(10, "The Flash", 2, 6, "Sigue las veloces aventuras de Barry Allen, un joven común y corriente con el deseo latente de ayudar a los demás. Cuando una inesperada partícula aceleradora golpea por accidente a Barry, de pronto se encuentra cargado de un increíble poder para moverse a increíbles velocidades. Mientras Barry siempre ha tenido el alma de un héroe, sus nuevos poderes le han dado la capacidad de actuar como tal."),
(11, "The Big Bang Theory", 2, 12, "Leonard y Sheldon son dos físicos que comparten trabajo y apartamento. La serie comienza con la mudanza de Penny, su nueva y atractiva vecina, y hace hincapié en la dificultad de los físicos para relacionarse con personas fuera de su entorno para dar lugar a situaciones cómicas."),
(12, "Friends", 2, 10, "'Friends' narra las aventuras y desventuras de seis jóvenes de Nueva York: Rachel, Monica, Phoebe, Ross, Chandler y Joey. Ellos forman una unida pandilla de amigos que viven en Manhattan y que suelen reunirse en sus apartamentos o en su bar habitual cafetería, el Central Perk. A pesar de los numerosos cambios que se producen en sus vidas, su amistad es inquebrantable en la dura batalla por salir adelante en sus periplos profesionales y personales."),
(13, "Anne with an 'E'", 2, 2, "Anne Shirley es una niña huérfana que vive en un pequeño pueblo llamado Avonlea que pertenece a la Isla del Príncipe Eduardo, en el año 1890. Después de una infancia difícil, donde fue pasando de orfanato a hogares de acogida, es enviada por error a vivir con una solterona y su hermano. Cuando cumple 13 años, Anne va a conseguir transformar su vida y el pequeño pueblo donde vive gracias a su fuerte personalidad, intelecto e imaginación. Basada en la inolvidable novela."),
(14, "Expedientes Secretos 'X'", 2, 11, "Fox Mulder y Dana Scully son dos investigadores del FBI que investigan casos sin resolución ni explicación, ya sea por razones paranormales (espíritus, criaturas extrañas, aliens...) ya porque el gobierno se ha encargado de ocultar todo tipo de pruebas. Cuando Mulder tenía doce años, su hermana pequeña fue secuestrada por unos desconocidos, aunque él cree que, en realidad, fue abducida por extraterrestres. Tras acabar sus estudios en la universidad de Oxford, ingresó en la Academia de Quantico, donde se ganó el apodo de 'siniestro'"),
(15, "Chernobyl", 2, 1, "Sigue «la verdadera historia de una de las peores catástrofes provocadas por el hombre y habla de los valientes hombres y mujeres que se sacrificaron para salvar a Europa de un desastre inimaginable. La miniserie se centra en el desgarrador alcance del desastre de la planta nuclear que ocurrió en Ucrania en abril de 1986, revelando cómo y por qué ocurrió, además contando las sorprendentes y notables historias de los héroes que lucharon y cayeron."),
(16, "Westworld", 2, 3, "'Westworld' es una oscura odisea acerca del amanecer de la conciencia artificial y la evolución del pecado. Situada en la intersección del futuro cercano y el pasado reimaginado, explora un mundo donde cada apetito humano, sin importar cuán noble o depravado, puede ser saciado. Está ambientada en un parque temático futurista dirigido por el Dr. Robert Ford (Anthony Hopkins). Las instalaciones cuentan con androides caracterizados del western americano, y gracias a ellos los visitantes pueden introducirse en cualquier tipo de fantasía por muy oscura que sea."),
(17, "Halt and Catch Fire", 2, 4, "Situada en los inicios de la década de 1980, un visionario ficticio, un ingeniero electrónico y una prodigiosa ingeniera, se alían a una programadora de software para confrontar con las corporaciones informáticas dominantes de la época. El Personal de la firma y sus socios de negocio, comenzarán una carrera que cambiará la cultura en el Estado de Texas, cuna de las empresas de tecnología, casi de la misma forma que lo es hoy Silicon Valey. \n Esta historia ficticia emula el trabajo realizado, en su momento, por la firma Compaq, cuando clonó el BIOS de las Computadoras Personales IBM, dando vida así al económico mercado de los clones. Mostrando también, a lo largo de sus 4 temporadas, el nacimiento de la arquitectura abierta de hardware, los videojuegos online, las salas de chat y de trueque de productos físicos, los BBS, y las primeras nubes computacionales, hasta la llegada de Internet (sin dejar afuera la guerra de los web browsers)."),
(18, "Ava", 1, null, "Ava es una mortífera asesina a sueldo que trabaja para una organización de operaciones encubiertas, que viaja por todo el mundo acabando con aquellos objetivos que nadie más puede derribar. Cuando uno de sus encargos sale mal, Ava tendrá que luchar por una vida."),
(19, "Aves de presa y la fantabulosa emancipación de una Harley Quinn", 1, null, "Después de separarse de Joker, Harley Quinn y otras tres heroínas (Canario Negro, Cazadora y Renée Montoya) unen sus fuerzas para salvar a una niña (Cassandra Cain) del malvado rey del crimen Máscara Negra."), 
(20, "Archivo", 1, null, "2038: George Almore está trabajando en una verdadera IA equivalente a la humana. Su último prototipo está casi listo. Esta fase sensible también es la más arriesgada. Especialmente porque tiene un objetivo que debe ocultarse a toda costa: reunirse con su esposa muerta."),
(21, "Jumanji - The next level", 1, null, "Las aventuras continúan en el fantástico mundo del video juego Jumanji, donde nada es lo que parece. En esta ocasión, los jugadores vuelven al juego, pero sus personajes se han intercambiado entre sí, lo que ofrece un curioso plantel: los mismos héroes con distinta apariencia y habilidades. Pero, ¿dónde está el resto de la gente?"),
(22, "3022", 1, null, "La película está ambientada en una estación espacial en el futuro. La tripulación sufre un estrés traumático y considera abandonar su misión después de observar lo que creen que es la destrucción de la Tierra. La película se muestra como una serie de flashbacks y flash-forward."),
(23, "IT - Capítulo 2", 1, null, "En este segundo capitulo Han pasado 27 años desde que el 'Club de los Perdedores', formado por Bill, Berverly, Richie, Ben, Eddie, Mike y Stanley, se enfrentaran al macabro y despiadado Pennywise (Bill Skarsgård). En cuanto tuvieron oportunidad, abandonaron el pueblo de Derry, en el estado de Maine, que tantos problemas les había ocasionado. Sin embargo, ahora, siendo adultos, parece que no pueden escapar de su pasado. Todos deberán enfrentarse de nuevo al temible payaso para descubrir si de verdad están preparados para superar sus traumas de la infancia."),
(24, "Pantera Negra", 1, null, "T Challa (Chadwick Boseman) regresa a su hogar en la apartada nación africana de Wakanda para servir como líder de su país. Tras suceder a su padre en el trono, pasa a convertirse en Pantera Negra, una sigilosa criatura de la noche, con agudos sentidos felinos y otras habilidades como súper fuerza e inteligencia, agilidad, estrategia o maestro del combate sin armas. Es bajo el liderazgo de T’Challa como Wakanda consigue convertirse en una de las naciones más ricas y tecnológicamente avanzadas del planeta."),
(25, "Contra lo imposible (Ford versus Ferrari)", 1, null,  "Los ganadores del Premio de la Academia® Matt Damon y Christian Bale protagonizan CONTRA LO IMPOSIBLE, basada en la historia real del visionario diseñador americano de automóviles Carroll Shelby (Damon) y el intrépido piloto británico Ken Miles (Bale). Juntos construyen un nuevo coche de carreras para Ford Motor Company y así enfrentar a Enzo Ferrari en las 24 Horas de Le Mans en Francia en 1966."),
(26, "Centígrados", 1, null, "Una joven pareja estadounidense viaja a las montañas árticas de Noruega. Después de detenerse durante una tormenta de nieve, se despiertan atrapados en su SUV, enterrados bajo capas de nieve y hielo."),
(27, "DOOM: Aniquilación", 1, null, "Doom: Aniquilación sigue a un grupo de marines espaciales que han respondido a una llamada de alerta de una base en la luna marciana, solo para descubrir que ha sido tomada por criaturas demoníacas que amenazan con desatar el infierno en la tierra."),
(28, "Contagio", 1, null, "De repente, sin saber cuál es su origen, aunque todo hace sospechar que comienza con el viaje de una norteamericana a un casino de Hong Kong, un virus mortal comienza a propagarse por todo el mundo. En pocos días, la enfermedad empieza a diezmar a la población. El contagio se produce por mero contacto entre los seres humanos. Un thriller realista y sin efectos especiales sobre los efectos de una epidemia."),
(29, "Viuda Negra", 1, null, "Primera pelicula individual de la Viuda Negra en el universo cinematografico de Marvel, contando su historia desde que se inició como doble agente rusa, su niñez, sus misiones, y su actualidad, después de Avengers."),
(30, "The Martian", 1, null,  "Durante una misión a Marte de la nave tripulada Ares III, una fuerte tormenta se desata dando por desaparecido y muerto al astronauta Mark Watney (Matt Damon), sus compañeros toman la decisión de irse pero él ha sobrevivido. Está solo y sin apenas recursos en el planeta. Con muy pocos medios deberá recurrir a sus conocimientos, su sentido del humor y un gran instinto de supervivencia para lograr sobrevivir y comunicar a la Tierra que todavía está vivo esperando que acudan en su rescate."),
(31, "Ex-Machina", 1, null, "Un programador multimillonario selecciona a Caleb, un joven empleado de su empresa, para que pase una semana en un lugar remoto con el objetivo de que participe en un test en el que estará involucrada su última creación: un robot-mujer en el que inteligencia artificial lo es todo."),
(32, "Jurassic World", 1, null, "Veintidós años después de lo ocurrido en Jurassic Park, la isla Nublar ha sido transformada en un enorme parque temático, Jurassic Wold, con versiones «domesticadas» de algunos de los dinosaurios más conocidos. Cuando todo parece ir sobre ruedas y ser el negocio del siglo, un nuevo dinosaurio de especie desconocida, pues ha sido creado manipulando genéticamente su ADN, y que resulta ser mucho más inteligente de lo que se pensaba, se escapa de su recinto y comienza a causar estragos entre los visitantes del Parque."),
(33, "Soy leyenda", 1, null, "Años después de que una plaga mate a la mayoría de la humanidad y transforme al resto en monstruos, el único superviviente en la ciudad de Nueva York lucha valientemente para encontrar una cura."),
(34, "El primer hombre en la luna", 1, null, "Cuenta la historia de la misión de la NASA que llevó al primer hombre a la luna, centrada en Neil Armstrong (interpretado por Ryan Gosling) y el periodo comprendido entre los años 1961 y 1969. Un relato en primera persona, basado en la novela de James R. Hansen, que explora el sacrificio y el precio que representó, tanto para Armstrong como para Estados Unidos, una de las misiones más peligrosas de la historia."),
(35, "Titanes del pacífico - La insurrección", 1, null, "Han pasado 10 años tras la primera invasión que sufrió la humanidad, pero la lucha aún no ha terminado. El planeta vuelve a ser asediado por los Kaiju, una raza de alienígenas colosales, que emergen desde un portal interdimensional con el objetivo de destruir a la raza humana. Ante esta nueva amenaza, los Jaegers, robots gigantes de guerra pilotados por dos personas para sobrellevar la inmensa carga neuronal que conlleva manipularlos, ya no están a la altura de lo que se les viene encima. Será entonces cuando los supervivientes de la primera invasión, además de nuevos personajes como el hijo de Pentecost, tendrán que idear la manera de sorprender al enorme enemigo, apostando por nuevas estrategias defensivas y de ataque. Con la Tierra en ruinas e intentando reconstruirse, esta nueva batalla puede ser decisiva para el futuro.");


insert into Reparto (idProduccion, idActor)
values
(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),
(2,7),(2,8),(2,9),(2,10),(2,11),(2,12),
(3,13),(3,14),(3,15),(3,16),(3,17),(3,18),
(4,19),(4,20),(4,21),(4,22),(4,23),(4,24),
(5,25),(5,26),(5,27),(5,28),(5,29),(5,30),
(6,31),(6,32),(6,33),(6,6),(6,34),(6,35),
(7,36),(7,37),(7,38),(7,39),(7,40),(7,41),
(8,42),(8,43),(8,44),(8,45),(8,46),(8,47),
(9,48),(9,49),(9,50),(9,51),(9,52),(9,53),
(10,54),(10,55),(10,56),(10,57),(10,58),(10,59),
(11,60),(11,61),(11,62),(11,63),(11,64),(11,65),(11,66),
(12,67),(12,68),(12,69),(12,70),(12,71),(12,72),
(13,73),(13,74),(13,75),(13,76),(13,77),(13,78),
(14,79),(14,80),(14,81),(14,82),(14,83),(14,84),
(15,85),(15,86),(15,87),(15,88),(15,89),(15,90),
(16,91),(16,92),(16,93),(16,94),(16,95),(16,96),
(17,97),(17,98),(17,99),(17,100),(17,101),(17,102),
(18,103),(18,104),(18,105),(18,106),(18,107),(18,108),
(19,109),(19,110),(19,111),(19,112),(19,113),(19,114),
(20,115),(20,116),(20,117),(20,118),(20,119),(20,120),
(21,121),(21,122),(21,123),(21,124),(21,125),(21,126),
(22,127),(22,128),(22,129),(22,130),(22,131),(22,132),
(23,133),(23,103),(23,134),(23,135),(23,136),(23,137),
(24,138),(24,139),(24,140),(24,141),(24,142),(24,143),
(25,144),(25,145),(25,146),(25,147),(25,148),(25,149),
(26,150),(26,151),(26,152),(26,153),
(27,154),(27,155),(27,156),(27,155),(27,158),(27,159),
(28,160),(28,145),(28,161),(28,162),(28,163),(28,164),(28,165),
(29,46),(29,166),(29,167),(29,168),(29,169),(29,170),(29,171),
(30,145),(30,103),(30,173),(30,174),(30,175),(30,176),(30,177),
(31,178),(31,179),(31,180),(31,181),(31,182),(31,183),(31,184),
(32,185),(32,186),(32,187),(32,188),(32,189),(32,190),(32,191),
(33,192),(33,193),(33,194),(33,195),(33,196),(33,197),(33,198),
(34,199),(34,200),(34,201),(34,202),(34,203),(34,204),
(35,205),(35,206),(35,207),(35,208),(35,209),(35,210);

insert into ContieneGenero (idProduccion, idGenero)
values
(1,3),(1,13),
(2,3),(2,12),(2,11),
(3,1),(3,5),
(4,1),(4,5),
(5,3),(5,11),(5,10),
(6,11),(6,3),(6,12),
(7,4),(7,2),(7,3),
(8,18),(8,14),(8,17),
(9,18),(9,5),(9,3),
(10,1),(10,5),
(11,6),(11,5),(11,11),
(12,6),(12,9),(12,3),
(13,3),(13,9),(13,15),
(14,3),(14,1),
(15,3),(15,13),
(16,15),(16,1),
(17,11),(17,3),(17,16),
(18,3),(18,2),
(19,17),(19,11),(19,6),
(20,17),(20,14),(20,2),
(21,6),(21,11),(21,18),
(22,1),(22,2),
(23,19),(23,2),(23,5),
(24,17),(24,18),(24,5),
(25,3),(25,7),(25,18),
(26,3),(26,2),(26,20),
(27,17),(27,14),(27,19),
(28,3),(28,2),(28,11),
(29,3),(29,17),(29,18),
(30,3),(30,14),(30,18),
(31,3),(31,14),(31,2),
(32,2),(32,18),(32,11),
(33,3),(33,19),(33,11),
(34,3),(34,13),
(35,17),(35,5),(35,14);


// Views

CREATE 
    ALGORITHM = UNDEFINED 
    DEFINER = `root`@`localhost` 
    SQL SECURITY DEFINER
VIEW `Trailerflix`.`ObtenerPostersView` AS
    SELECT 
        `Po`.`idPoster` AS `idPoster`,
        `Po`.`recurso` AS `recurso`,
        `Po`.`idProduccion` AS `idProduccion`,
        `P`.`titulo` AS `tituloProduccion`
    FROM
        (`Trailerflix`.`Poster` `Po`
        JOIN `Trailerflix`.`Produccion` `P` ON ((`Po`.`idProduccion` = `P`.`idProduccion`)))
        
        


CREATE 
    ALGORITHM = UNDEFINED 
    DEFINER = `root`@`localhost` 
    SQL SECURITY DEFINER
VIEW `Trailerflix`.`ObtenerTrailersView` AS
    SELECT 
        `T`.`idTrailer` AS `idTrailer`,
        `T`.`direccionURL` AS `URL`,
        `T`.`idProduccion` AS `idProduccion`,
        `P`.`titulo` AS `tituloProduccion`
    FROM
        (`Trailerflix`.`Trailer` `T`
        JOIN `Trailerflix`.`Produccion` `P` ON ((`T`.`idProduccion` = `P`.`idProduccion`)))
        



CREATE 
    ALGORITHM = UNDEFINED 
    DEFINER = `root`@`localhost` 
    SQL SECURITY DEFINER
VIEW `Trailerflix`.`ProduccionGeneralView` AS
    SELECT 
        `P`.`idProduccion` AS `id`,
        `Po`.`recurso` AS `poster`,
        `P`.`titulo` AS `titulo`,
        `C`.`nombre` AS `categoria`,
        GROUP_CONCAT(DISTINCT `G`.`nombre`
            ORDER BY `G`.`nombre` ASC
            SEPARATOR ',') AS `genero`,
        `P`.`resumen` AS `resumen`,
        `P`.`temporadas` AS `temporadas`,
        GROUP_CONCAT(DISTINCT `A`.`nombreCompleto`
            ORDER BY `A`.`nombreCompleto` ASC
            SEPARATOR ',') AS `reparto`,
        `T`.`direccionURL` AS `trailer`
    FROM
        (((((((`Trailerflix`.`Produccion` `P`
        JOIN `Trailerflix`.`Poster` `Po` ON ((`Po`.`idProduccion` = `P`.`idProduccion`)))
        JOIN `Trailerflix`.`Categoria` `C` ON ((`P`.`categoria` = `C`.`idCategoria`)))
        JOIN `Trailerflix`.`ContieneGenero` `CG` ON ((`P`.`idProduccion` = `CG`.`idProduccion`)))
        JOIN `Trailerflix`.`Genero` `G` ON ((`CG`.`idGenero` = `G`.`idGenero`)))
        JOIN `Trailerflix`.`Reparto` `R` ON ((`P`.`idProduccion` = `R`.`idProduccion`)))
        JOIN `Trailerflix`.`Actores` `A` ON ((`R`.`idActor` = `A`.`idActor`)))
        JOIN `Trailerflix`.`Trailer` `T` ON ((`P`.`idProduccion` = `T`.`idProduccion`)))
    GROUP BY `P`.`idProduccion` , `Po`.`recurso` , `P`.`titulo` , `C`.`nombre` , `P`.`resumen` , `P`.`temporadas` , `T`.`direccionURL`
