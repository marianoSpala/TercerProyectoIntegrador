const dotenv = require('dotenv');
dotenv.config();
const {db} = require('./conexion');


//funcion para autenticar la conexion a la DD.BB
async function authenticate() {
    try{
        await db.authenticate();
        console.log('Conexion establecida correctamente');
    } catch (error) {
        console.error('Error al conectar con la DD.BB:', error);
    }
}

//funcion para cerrar coneccion con la DD.BB
async function closeConnection() {
    try{
        await db.close();
        console.log('Conexion cerrada correctamente');
    } catch (error) {
        console.error('Error al cerrar la DD.BB:', error);
    }
}

module.exports = {authenticate, closeConnection};
