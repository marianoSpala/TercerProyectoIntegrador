//importacion de modelos de Tablas
const Actores = require('../models/actores');
const Categoria = require('../models/categoria');
const Genero = require('../models/genero');
const Poster = require('../models/poster');
const Produccion = require('../models/produccion');
const Trailer = require('../models/trailer');
const Reparto = require('../models/reparto');
const ContieneGenero = require('../models/contieneGenero');


//Relaciones entre tablas

Produccion.hasOne(Poster, {foreignKey: 'idProduccion'});
Poster.belongsTo(Produccion, {foreignKey:'idProduccion'});

Categoria.hasMany(Produccion, {foreignKey:'categoria'});
Produccion.belongsTo(Categoria, {foreignKey:'categoria'});

Produccion.hasOne(Trailer, {foreignKey:'idProduccion'});
Trailer.belongsTo(Produccion, {foreignKey:'idProduccion'});

Produccion.belongsToMany(Genero, { through: 'ContieneGenero', foreignKey:'idProduccion'});
Genero.belongsToMany(Produccion, { through: 'ContieneGenero', foreignKey:'idGenero'});

Produccion.belongsToMany(Actores, {through: 'Reparto', foreignKey:'idProduccion'});
Actores.belongsToMany(Produccion, {through: 'Reparto', foreignKey:'idActor'});



module.exports = {
Produccion,
Actores,
Categoria,
Genero,
Trailer,
Poster,
ContieneGenero,
Reparto,
};